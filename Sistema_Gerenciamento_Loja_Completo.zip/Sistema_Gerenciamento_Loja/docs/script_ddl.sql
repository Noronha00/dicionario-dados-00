-- Sistema de Gerenciamento de Loja
-- SGBD alvo: PostgreSQL 15+
-- Script de referência acadêmica; executar em banco vazio.

CREATE TABLE clientes (
    cliente_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    cpf CHAR(11) NOT NULL UNIQUE,
    email VARCHAR(160) UNIQUE,
    telefone VARCHAR(20),
    data_cadastro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT ck_clientes_cpf CHECK (cpf ~ '^[0-9]{11}$')
);

CREATE TABLE funcionarios (
    funcionario_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    cpf CHAR(11) NOT NULL UNIQUE,
    email VARCHAR(160) NOT NULL UNIQUE,
    cargo VARCHAR(60) NOT NULL,
    data_admissao DATE NOT NULL,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT ck_funcionarios_cpf CHECK (cpf ~ '^[0-9]{11}$')
);

CREATE TABLE categorias (
    categoria_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nome VARCHAR(80) NOT NULL UNIQUE,
    descricao VARCHAR(300),
    ativa BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE fornecedores (
    fornecedor_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    razao_social VARCHAR(150) NOT NULL,
    cnpj CHAR(14) NOT NULL UNIQUE,
    email VARCHAR(160),
    telefone VARCHAR(20),
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT ck_fornecedores_cnpj CHECK (cnpj ~ '^[0-9]{14}$')
);

CREATE TABLE produtos (
    produto_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    categoria_id BIGINT NOT NULL REFERENCES categorias(categoria_id),
    fornecedor_id BIGINT REFERENCES fornecedores(fornecedor_id),
    nome VARCHAR(140) NOT NULL,
    descricao VARCHAR(500),
    sku VARCHAR(40) NOT NULL UNIQUE,
    preco_venda NUMERIC(12,2) NOT NULL,
    custo NUMERIC(12,2) NOT NULL,
    quantidade_estoque INTEGER NOT NULL DEFAULT 0,
    estoque_minimo INTEGER NOT NULL DEFAULT 0,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT ck_produtos_preco CHECK (preco_venda >= 0),
    CONSTRAINT ck_produtos_custo CHECK (custo >= 0),
    CONSTRAINT ck_produtos_estoque CHECK (quantidade_estoque >= 0 AND estoque_minimo >= 0)
);

CREATE TABLE vendas (
    venda_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    cliente_id BIGINT REFERENCES clientes(cliente_id),
    funcionario_id BIGINT NOT NULL REFERENCES funcionarios(funcionario_id),
    data_venda TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) NOT NULL DEFAULT 'ABERTA',
    valor_bruto NUMERIC(12,2) NOT NULL DEFAULT 0,
    desconto NUMERIC(12,2) NOT NULL DEFAULT 0,
    valor_total NUMERIC(12,2) NOT NULL DEFAULT 0,
    CONSTRAINT ck_vendas_status CHECK (status IN ('ABERTA','PAGA','CANCELADA')),
    CONSTRAINT ck_vendas_valores CHECK (valor_bruto >= 0 AND desconto >= 0 AND valor_total >= 0 AND desconto <= valor_bruto)
);

CREATE TABLE itens_venda (
    item_venda_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    venda_id BIGINT NOT NULL REFERENCES vendas(venda_id) ON DELETE CASCADE,
    produto_id BIGINT NOT NULL REFERENCES produtos(produto_id),
    quantidade INTEGER NOT NULL,
    preco_unitario NUMERIC(12,2) NOT NULL,
    subtotal NUMERIC(12,2) NOT NULL,
    CONSTRAINT uq_itens_venda_produto UNIQUE (venda_id, produto_id),
    CONSTRAINT ck_itens_quantidade CHECK (quantidade > 0),
    CONSTRAINT ck_itens_precos CHECK (preco_unitario >= 0 AND subtotal >= 0)
);

CREATE TABLE pagamentos (
    pagamento_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    venda_id BIGINT NOT NULL REFERENCES vendas(venda_id) ON DELETE CASCADE,
    data_pagamento TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    forma_pagamento VARCHAR(20) NOT NULL,
    valor NUMERIC(12,2) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'CONFIRMADO',
    transacao_ref VARCHAR(100) UNIQUE,
    CONSTRAINT ck_pagamentos_forma CHECK (forma_pagamento IN ('DINHEIRO','PIX','CREDITO','DEBITO','BOLETO')),
    CONSTRAINT ck_pagamentos_status CHECK (status IN ('PENDENTE','CONFIRMADO','ESTORNADO')),
    CONSTRAINT ck_pagamentos_valor CHECK (valor > 0)
);

CREATE TABLE movimentacoes_estoque (
    movimentacao_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    produto_id BIGINT NOT NULL REFERENCES produtos(produto_id),
    funcionario_id BIGINT NOT NULL REFERENCES funcionarios(funcionario_id),
    venda_id BIGINT REFERENCES vendas(venda_id),
    tipo VARCHAR(12) NOT NULL,
    quantidade INTEGER NOT NULL,
    motivo VARCHAR(200),
    data_movimentacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_mov_tipo CHECK (tipo IN ('ENTRADA','SAIDA','AJUSTE')),
    CONSTRAINT ck_mov_quantidade CHECK (quantidade > 0)
);

CREATE INDEX idx_produtos_categoria ON produtos(categoria_id);
CREATE INDEX idx_vendas_data ON vendas(data_venda);
CREATE INDEX idx_vendas_cliente ON vendas(cliente_id);
CREATE INDEX idx_itens_venda_venda ON itens_venda(venda_id);
CREATE INDEX idx_mov_produto_data ON movimentacoes_estoque(produto_id, data_movimentacao);

-- Regras de negócio que devem ser implementadas pela aplicação ou por procedures/triggers:
-- RN01: venda só pode ser finalizada se possuir ao menos um item.
-- RN02: estoque não pode ficar negativo; registrar movimentação para cada entrada/saída.
-- RN03: subtotal do item = quantidade * preço_unitário; total da venda = soma dos subtotais - desconto.
-- RN04: venda marcada como PAGA deve possuir pagamentos confirmados que totalizem o valor_total.
-- RN05: produto inativo não pode ser incluído em novas vendas.
-- RN06: CPF/CNPJ são armazenados apenas com dígitos; validar dígitos verificadores na aplicação.
-- RN07: não excluir registros históricos de vendas/pagamentos; usar status/inativação.

# Sistema de Gerenciamento de Loja — Dicionário de Dados

Projeto acadêmico demonstrativo criado do zero para estudo de modelagem, SQL e governança de dados.

## Conteúdo
- `index.html`, `style.css`, `script.js`: dicionário web com busca em tempo real, tema claro/escuro e modal do DER com Panzoom.
- `docs/Especificacao_Requisitos_Regras_Negocio_BD.pdf`: especificação e histórico de revisões.
- `docs/script_ddl.sql`: DDL PostgreSQL.
- `docs/dicionario_metadados.json`: metadados das nove tabelas.
- `assets/der.png`: diagrama entidade-relacionamento.

## Publicação
Enviar o conteúdo desta pasta para a raiz de um repositório GitHub e ativar Settings > Pages > Deploy from a branch > main > /(root).

## Observações
A proposta contém nove tabelas: clientes, funcionarios, categorias, fornecedores, produtos, vendas, itens_venda, pagamentos e movimentacoes_estoque. Regras que dependem de mais de uma tabela (como conciliação de pagamentos e baixa de estoque) precisam de transação na aplicação ou triggers/procedures e testes. Validar o conteúdo com o professor antes da entrega.
